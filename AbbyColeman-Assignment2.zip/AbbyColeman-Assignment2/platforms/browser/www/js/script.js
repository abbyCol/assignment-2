var app = new Framework7({
    root: "#app",
    routes: [
        {
            path: '/page2/',
            url: 'pages/page2.html',
        },
        {
            path: '/page3/',
            url: 'pages/page3.html',
        },
        {
            path: '/page4/',
            url: 'pages/page4.html',
        }
    ]
});

var $$ = Dom7;

var mainView = app.views.create('.view-main');

var map, heatmap, heatmapData;




//init(); //only for comp


$(document).ready(function () { // code from Kuldeep Pisda on Quora forums: https://www.quora.com/How-can-I-make-a-full-page-load-screen-in-JavaScript-or-jQuery
    $('#preloader').delay(2000).fadeOut();
});

document.addEventListener("deviceready", init, false);

function init() {
    console.log("ready to roll");

    var geoOpts = {
        //        timeout: 2000,
        //enableHighAccuracy: true
    }

    function geoSuccess(position) {
        console.log("i found you");

        heatmapData = [
            new google.maps.LatLng({
                lat: position.coords.latitude,
                lng: position.coords.longitude
            })
        ];

        //        heatmap.set('data', newdata)

        map = new google.maps.Map(document.getElementById('map'), {
            zoom: 17,
            center: {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            },
            styles: [
                {
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#3f473f"
      }
    ]
  },
                {
                    "elementType": "labels.text.stroke",
                    "stylers": [
                        {
                            "color": "#ffffff"
      }
    ]
  },
                {
                    "featureType": "administrative.land_parcel",
                    "elementType": "labels",
                    "stylers": [
                        {
                            "visibility": "off"
      }
    ]
  },
                {
                    "featureType": "landscape.man_made",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#bbd2c1"
      }
    ]
  },
                {
                    "featureType": "landscape.natural",
                    "elementType": "geometry.fill",
                    "stylers": [
                        {
                            "color": "#dde1dd"
      }
    ]
  },
                {
                    "featureType": "poi",
                    "elementType": "labels.text",
                    "stylers": [
                        {
                            "visibility": "off"
      }
    ]
  },
                {
                    "featureType": "road.highway",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#fafa94"
      }
    ]
  },
                {
                    "featureType": "road.local",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#ffffff"
      }
    ]
  },
                {
                    "featureType": "road.local",
                    "elementType": "labels",
                    "stylers": [
                        {
                            "visibility": "off"
      }
    ]
  },
                {
                    "featureType": "water",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#89c1ef"
      }
    ]
  }
]
        });


        marker = new google.maps.Marker({
            position: {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            },
            map: map
        });

        heatmap = new google.maps.visualization.HeatmapLayer({
            data: heatmapData,
            radius: 30
        });
        heatmap.setMap(map);

        watchID = navigator.geolocation.watchPosition(watchSuccess, geoError, geoOpts);

    }

    function watchSuccess(position) {
        var coords = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
        }
        marker.setPosition(coords);
        heatmapData.push(new google.maps.LatLng({
            lat: position.coords.latitude,
            lng: position.coords.longitude
        }))
        console.log("data update: " + JSON.stringify(heatmapData))
        heatmap.setData(heatmapData);
    }

    function geoError(message) {
        alert("oh oh " + message.message + " Error code: " + message.code)
    }
    navigator.geolocation.getCurrentPosition(geoSuccess, geoError, geoOpts);
}
